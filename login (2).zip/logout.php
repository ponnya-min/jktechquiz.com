<?php
session_start();

// Include the database connection file
require('config.php');

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Clear session token in the database
    $stmt = $conn->prepare("UPDATE users SET session_token = NULL WHERE id = :id");
    if ($stmt) {
        $stmt->execute(['id' => $user_id]);
    }
    


    // Clear session data
    session_unset();
    session_destroy();

    header("Location: login.php");
    exit();
}
?>

