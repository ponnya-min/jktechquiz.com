<?php
require_once '../../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $sql = "DELETE FROM users WHERE DATEDIFF(NOW(), last_login) > 180";
        $stmt = $conn->prepare($sql);

        if ($stmt->execute()) {
            header("Location: ../index.php?message=Expired accounts deleted successfully");
            exit();
        } else {
            echo "Error deleting expired accounts.";
        }
    } catch (PDOException $e) {
        die("Error: " . htmlspecialchars($e->getMessage()));
    }
} else {
    echo "Invalid request.";
}

$conn = null;
?>
