<?php
require_once '../../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id"])) {
    $id = $_POST["id"];

    try {
        $sql = "DELETE FROM users WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            header("Location: ../index.php?message=User deleted successfully");
            exit();
        } else {
            echo "Error deleting user.";
        }
    } catch (PDOException $e) {
        die("Error: " . htmlspecialchars($e->getMessage()));
    }
} else {
    echo "Invalid request.";
}

$conn = null;
?>
