<?php
require_once '../config.php';

$perPage = 8;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $perPage;

try {
    $sql = "SELECT id, username, email, 
            DATE_FORMAT(last_login, '%d.%m.%Y (%h:%i %p)') AS formatted_last_login,
            COALESCE(DATEDIFF(NOW(), last_login), 'None') AS days_since_last_login,
            IF(DATEDIFF(NOW(), last_login) > 180, 'YES', 'NO') AS expired_account
        FROM users
        LIMIT :limit OFFSET :offset";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
} catch (PDOException $e) {
    die("Error: " . htmlspecialchars($e->getMessage()));
}

$sqlCount = "SELECT COUNT(*) FROM users";
$stmtCount = $conn->prepare($sqlCount);
$stmtCount->execute();
$totalRows = $stmtCount->fetchColumn();
$totalPages = ceil($totalRows / $perPage);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container">
            <a class="navbar-brand" href=""><img alt="logo" height="60" src="img/1-removebg-preview.png" /></a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item px-2"><a class="nav-link" href="adminRole.php"><i class="fa-solid fa-user-tie"></i> Admin</a></li>
                    <li class="nav-item px-2"><a class="nav-link" href="index.php"><i class="fa-solid fa-user"></i> User</a></li>
                    <li class="nav-item px-2"><a class="nav-link" href="result.php"><i class="fa-solid fa-ranking-star"></i> Result</a></li>
                    <li class="nav-item px-2"><a class="nav-link" href="comment.php"><i class="fa-solid fa-comment"></i> Comment</a></li>
                </ul>
                <!-- Logout button -->
                <a class="btn btn-danger" href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h3 class="mb-3">User Table</h3>
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteExpiredModal">
                Delete Expired Acc
            </button>
        </div>

        <div class="table-responsive">
            <?php if ($stmt->rowCount() > 0): ?>
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Last Login</th>
                            <th>Last Active</th>
                            <th>Expired Acc</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $counter = $offset + 1;
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
                        ?>
                            <tr>
                                <td><?= $counter++ ?></td>
                                <td><?= htmlspecialchars($row["username"]) ?></td>
                                <td><?= htmlspecialchars($row["email"]) ?></td>
                                <td>
                                    <?php
                                    if (!empty($row["formatted_last_login"])) {
                                        $dateTimeParts = explode(' ', $row["formatted_last_login"], 2);
                                        echo htmlspecialchars($dateTimeParts[0]) . "<br>" . htmlspecialchars($dateTimeParts[1]);
                                    } else {
                                        echo "None";
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    if ($row["days_since_last_login"] === 'None') {
                                        echo "None";
                                    } else {
                                        $days = (int)$row["days_since_last_login"];
                                        if ($days == 0) {
                                            echo "Today";
                                        } elseif ($days == 1) {
                                            echo "1 day ago";
                                        } elseif ($days < 30) {
                                            echo "$days days ago";
                                        } elseif ($days < 365) {
                                            $months = floor($days / 30);
                                            echo $months == 1 ? "1 month ago" : "$months months ago";
                                        } else {
                                            $years = floor($days / 365);
                                            echo $years == 1 ? "1 year ago" : "$years years ago";
                                        }
                                    }
                                    ?>
                                </td>
                                <td><?= htmlspecialchars($row["expired_account"]) ?></td>
                                <td>
                                    <button type="button" class="btn btn-danger" onclick="confirmDelete(<?= htmlspecialchars($row['id']) ?>)">
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page - 1 ?>">Previous</a>
                        </li>
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?= ($page >= $totalPages) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            <?php else: ?>
                <p class="text-center">No users found.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Delete User Modal -->
    <div class="modal fade" id="deleteUserModal" tabindex="-1" aria-labelledby="deleteUserModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">Are you sure you want to delete this user?</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" action="manageUser/deleteAcc.php">
                        <input type="hidden" id="deleteUserId" name="id">
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Expired Accounts Modal -->
    <div class="modal fade" id="deleteExpiredModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Delete Expired Account?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">Are you sure you want to delete all expired accounts?</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" action="manageUser/deleteExpiredAcc.php">
                        <button type="submit" class="btn btn-danger">Delete All</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function confirmDelete(userId) {
            document.getElementById("deleteUserId").value = userId;
            var modal = new bootstrap.Modal(document.getElementById('deleteUserModal'));
            modal.show();
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php $conn = null; ?>