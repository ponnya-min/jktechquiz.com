<?php
require_once '../config.php';

$perPage = 8;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $perPage;


try {
    $sql = "SELECT id, name, email, role FROM admins LIMIT :limit OFFSET :offset";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
} catch (PDOException $e) {
    die("Error: " . htmlspecialchars($e->getMessage()));
}

$sqlCount = "SELECT COUNT(*) FROM admins";
$stmtCount = $conn->prepare($sqlCount);
$stmtCount->execute();
$totalRows = $stmtCount->fetchColumn();
$totalPages = ceil($totalRows / $perPage);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
<nav class="navbar navbar-expand-lg bg-light">
    <div class="container">
        <a class="navbar-brand" href=""><img alt="logo" height="60" src="img/1-removebg-preview.png" /></a>
        <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item px-2"><a class="nav-link" href="adminRole.php"><i class="fa-solid fa-user-tie"></i> Admin</a></li>
                <li class="nav-item px-2"><a class="nav-link" href="index.php"><i class="fa-solid fa-user"></i> User</a></li>
                <li class="nav-item px-2"><a class="nav-link" href="result.php"><i class="fa-solid fa-ranking-star"></i> Result</a></li>
                <li class="nav-item px-2"><a class="nav-link" href="comment.php"><i class="fa-solid fa-comment"></i> Comment</a></li>
            </ul>
            <!-- Logout button -->
            <a class="btn btn-danger" href="logout.php">Logout</a>
        </div>
    </div>
</nav>

    <div class="container mt-4">
        <h3>User Management</h3>
        <!-- Display Success/Error Messages -->
        <?php
        if (isset($_SESSION['message'])) {
            echo '<div class="alert alert-success">' . $_SESSION['message'] . '</div>';
            unset($_SESSION['message']); // Clear message after displaying
        }

        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']); // Clear message after displaying
        }
        ?>
        <div class="table-responsive">
            <?php if ($stmt->rowCount() > 0): ?>
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $rowNumber = $offset + 1; ?>
                        <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                            <tr id="row<?= $row['id'] ?>">
                                <td><?= $rowNumber++ ?></td>
                                <td><?= htmlspecialchars($row["name"]) ?></td>
                                <td><?= htmlspecialchars($row["email"]) ?></td>
                                <td>
                                    <!-- Disable role select for admin@gmail.com -->
                                    <select class="form-select roleSelect" data-id="<?= $row["id"] ?>" <?= ($row["email"] == 'admin@gmail.com') ? 'disabled' : '' ?>>
                                        <option value="user" <?= ($row["role"] == "user") ? 'selected' : '' ?>>User</option>
                                        <option value="admin" <?= ($row["role"] == "admin") ? 'selected' : '' ?>>Admin</option>
                                    </select>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-danger" onclick="confirmDelete(<?= htmlspecialchars($row['id']) ?>)" <?= ($row["id"] == 1) ? 'disabled' : '' ?>>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <nav>
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page - 1 ?>">Previous</a>
                        </li>

                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>

                        <li class="page-item <?= ($page >= $totalPages) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            <?php else: ?>
                <p class="text-center">No users found.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Delete Admin Modal -->
    <div class="modal fade" id="deleteAdminModal" tabindex="-1" aria-labelledby="deleteAdminModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">Are you sure you want to delete this admin?</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" action="manageAdmin/deleteAdmin.php">
                        <input type="hidden" id="deleteAdminId" name="id">
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Role Change Confirmation Modal -->
    <div class="modal fade" id="confirmRoleChangeModal" tabindex="-1" aria-labelledby="confirmRoleChangeLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmRoleChangeLabel">Confirm Role Change</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to change this user's role?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="cancelRoleChange" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmRoleChange">Confirm</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Toast Notification (for success/error messages) -->
    <div class="toast" id="toastMessage" style="position: absolute; top: 20px; right: 20px; display: none;">
        <div class="toast-body">
            <!-- Toast message will appear here -->
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        let selectedUserId = null;
        let selectedRole = null;
        let previousRole = null;

        $(document).ready(function() {
            // When role selection changes, show confirmation modal
            $(document).on("change", ".roleSelect", function() {
                selectedUserId = $(this).data("id");
                selectedRole = $(this).val();
                previousRole = $(this).find("option[selected]").val();

                // Show confirmation modal
                var modal = new bootstrap.Modal(document.getElementById('confirmRoleChangeModal'));
                modal.show();
            });

            // Confirm Role Change
            $("#confirmRoleChange").on("click", function() {
                $.ajax({
                    url: "manageAdmin/changeRole.php",
                    type: "POST",
                    data: {
                        id: selectedUserId,
                        role: selectedRole
                    },
                    dataType: "json",
                    success: function(response) {
                        if (response.success) {
                            showToast("success", response.message);
                        } else {
                            showToast("danger", response.error);
                            $('.roleSelect[data-id="' + selectedUserId + '"]').val(previousRole); // Revert
                        }

                        $("#confirmRoleChangeModal").modal('hide');
                    },
                    error: function() {
                        showToast("danger", "Error updating role. Please try again.");
                        $('.roleSelect[data-id="' + selectedUserId + '"]').val(previousRole); // Revert
                        $("#confirmRoleChangeModal").modal('hide');
                    }
                });
            });

            // Cancel Role Change (Revert selection)
            $("#cancelRoleChange").on("click", function() {
                $('.roleSelect[data-id="' + selectedUserId + '"]').val(previousRole);
            });

            // Show Toast Notification
            function showToast(type, message) {
                $("#toastMessage").removeClass("bg-success bg-danger").addClass("bg-" + type);
                $("#toastMessage .toast-body").text(message);
                var toast = new bootstrap.Toast(document.getElementById('toastMessage'));
                toast.show();
            }
        });

        function confirmDelete(adminId) {
            document.getElementById("deleteAdminId").value = adminId;
            var modal = new bootstrap.Modal(document.getElementById('deleteAdminModal'));
            modal.show();
        }
    </script>
</body>

</html>