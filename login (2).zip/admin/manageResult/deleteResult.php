<?php
require_once '../../config.php';

if (isset($_POST['result_id'])) {
    $resultId = (int)$_POST['result_id'];

    try {
        $sql = "DELETE FROM result WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $resultId, PDO::PARAM_INT);
        $stmt->execute();

        header('Location: ../result.php'); // Redirect back to the results page after deletion
        exit;
    } catch (PDOException $e) {
        die("Error: " . htmlspecialchars($e->getMessage()));
    }
}
?>
