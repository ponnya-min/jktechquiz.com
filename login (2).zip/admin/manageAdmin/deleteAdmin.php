<?php
require_once '../../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the ID of the admin to be deleted
    $adminId = isset($_POST['id']) ? (int)$_POST['id'] : 0;

    if ($adminId > 0) {
        try {
            // Delete the admin from the database
            $sql = "DELETE FROM admins WHERE id = :id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':id', $adminId, PDO::PARAM_INT);
            $stmt->execute();

            // Check if a row was deleted
            if ($stmt->rowCount() > 0) {
                // Redirect back to the index.php with a success message in the session
                session_start();
                $_SESSION['message'] = 'Admin deleted successfully';
            } else {
                // Redirect back with an error message
                session_start();
                $_SESSION['error'] = 'Admin not found';
            }
        } catch (PDOException $e) {
            session_start();
            $_SESSION['error'] = 'Error deleting admin: ' . $e->getMessage();
        }
    } else {
        session_start();
        $_SESSION['error'] = 'Invalid admin ID';
    }
    
    // Redirect back to index.php after processing
    header("Location: ../adminRole.php");
    exit;
}