<?php
require_once '../../config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"], $_POST["role"])) {
    $id = $_POST["id"];
    $role = $_POST["role"];

    try {
        $sql = "UPDATE admins SET role = :role WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":role", $role, PDO::PARAM_STR);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "Role updated successfully."]);
        } else {
            echo json_encode(["error" => "Failed to update role."]);
        }
    } catch (PDOException $e) {
        echo json_encode(["error" => htmlspecialchars($e->getMessage())]);
    }
} else {
    echo json_encode(["error" => "Invalid request"]);
}
?>