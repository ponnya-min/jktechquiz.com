<?php
require("../../config.php");

$sql = "DELETE FROM feedback";
$stmt = $conn->prepare($sql);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error";
}
?>
