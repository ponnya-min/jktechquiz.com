<?php
require("../../config.php");

if (isset($_POST['date'])) {
    $date = $_POST['date'];
    $sql = "DELETE FROM feedback WHERE date = :date";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':date', $date, PDO::PARAM_STR);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }
} else {
    echo "Invalid request";
}
