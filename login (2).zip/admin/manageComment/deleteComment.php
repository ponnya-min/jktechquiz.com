<?php
require("../../config.php");

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!empty($_POST['id'])) {
        $commentId = $_POST['id'];

        // Check if comment exists
        $checkSql = "SELECT * FROM feedback WHERE id = :id";
        $checkStmt = $conn->prepare($checkSql);
        $checkStmt->bindParam(':id', $commentId, PDO::PARAM_INT);
        $checkStmt->execute();

        if ($checkStmt->rowCount() > 0) {
            // Delete query
            $sql = "DELETE FROM feedback WHERE id = :id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':id', $commentId, PDO::PARAM_INT);

            if ($stmt->execute()) {
                echo "success";
            } else {
                echo "error";
            }
        } else {
            echo "not_found";
        }
    } else {
        echo "invalid";
    }
} else {
    echo "invalid_request";
}
?>
